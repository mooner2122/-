//
//  ViewController.h
//  微信支付
//
//  Created by 震海科技 on 15/12/16.
//  Copyright © 2015年 震海科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

